# Car plate > 2024-10-01 12:40am
https://universe.roboflow.com/safwan-ayocu/car-plate-jgpye

Provided by a Roboflow user
License: CC BY 4.0

